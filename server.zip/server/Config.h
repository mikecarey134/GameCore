#pragma once
#include<iostream>
#include<string>
#include<vector>
#include<fstream>

class Config
{

public:
	//indexes for extracting data from the vector
	enum config_vals{PORT=0,NUM_CONNECTIONS};
	Config(std::string file_name);
	~Config(void);

	//read in all the data from the file and store it in the vector
	void read_lines(std::string& str, std::ifstream& file);
	
	int get_num_connections(){return atoi(vals_[NUM_CONNECTIONS].c_str());}
	const char* get_port_number  (){return vals_[PORT].c_str();}

private:
	std::string file_name_;
	std::vector<std::string> vals_;

};
