#include "Config.h"


using namespace std;

Config::Config(std::string file_name):file_name_(file_name)
{
	ifstream in_file;
	string str;
	in_file.open(file_name_.c_str());
	if(in_file.fail())
		exit(-1);
	
	read_lines(str,in_file);
	in_file.close();

	std::cout<<"Config Read!\n";
}

Config::~Config(void)
{
}
void Config::read_lines(std::string& str, ifstream& file )
{
	
	while(getline(file,str))
	{
		if(str[0] == '#')//ignore comment lines
		{
			str="";
		
		}
		else//otherwise push the configuration data onto the vector order is important
			vals_.push_back(str);
			
	}

	
}