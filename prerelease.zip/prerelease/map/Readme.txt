If you would like to change the loaded level just rename subbs2 to subbs after you rename the original subbs
file

thanks 

-Mike
-Gamecore Developer