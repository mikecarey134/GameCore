
#Disclaimer
/////////////////////////////////////////////////////////////////////////////////////////////////////////
This is the prerelease demo for gamecore a game engine written in c++ using the Irrlicht graphics engine
and Raknet Networking lib all models were created by Michael Carey and Dan Brown and all testures were 
either made in photoshop or are opensource. 
////////////////////////////////////////////////////////////////////////////////////////////////////////

#system 
//////////////////////////////////////////////////////////////////////
-Make sure to have Microsoft Visual c++ redistributable 2008 installed 
-Make sure your OpenGL Drivers are up to date
-Minimum of 2Gigs of ram
-Moble Graphics or higher check for updates
//////////////////////////////////////////////////////////////////////


#Purpose
////////////////////////////////////////////////////////////////////
the purpose of this project is to build a game core that allows 
other programmers to have a basic game in which 
they can create their own custom application and not have to worry
too much about mechanics 
///////////////////////////////////////////////////////////////////

#controls
/////////////////////////////////////////////////////
-WSAD walking
-E enventory (alpha state)
-F flashlight (works on the open map)
-~ brings up the console (see commands below \/)
-ESC brings up the pause menu
-Left mouse (attack, only the animation plays)
-Space player jump
//////////////////////////////////////////////////////

#console commands
//////////////////////////////////////////////////////
use ~ to bring up the console
\ indicates a command 
//////////////////////////////////////////////////////

\cls (clear the console)

\list (gives you all the commands)

\help <command> (gets help for a particular command

\echo (echos that string)

\rb <path> <size> (adds a 3d model of a particular size to the world near the player)
  +ex. \rb test/crate.obj .5 

\pgv <value> (sets the players gravity) moon jump anyone?

\gv <value> (sets the world gravity) 

\tp <x> <y> <z> (teleports the player to x,y,z coords)
//////////////////////////////////////////////////////////


#credits
//////////////////////////////////////////////////////////////////
Thats it hope you have fun testing our demo please make sure to
give us credit if you forward this project

(carey_m@students.lynchburg.edu mikecarey134@gmail.com)
///////////////////////////////////////////////////////////////////
Document by: Mike Carey  
///////////////////////////////////////////////////////////////////